/*
 * Njc_Sci_Drv.h
 *
 *  Created on: 2020��7��6��
 *      Author: ning_
 */
#include"F28x_Project.h"

#ifndef NJC_SCI_DRV_H_
#define NJC_SCI_DRV_H_
#define Sci_Regs_Pt ((volatile struct SCI_REGS *)target->port_handle_address)

#define LaunchPad 2

typedef struct Sci_Obj
{
    Uint16 port;
    Uint32 port_handle_address;
    Uint32 Lsp_Clk;
    Uint32 Baud_rate;
}Sci_Obj_Int;

typedef Sci_Obj_Int *Sci_Obj_Int_p;

extern Sci_Obj_Int_p InitSciCfg(void *MemAdd,const Uint16 MemSize);
extern void SciCfg(Sci_Obj_Int_p target,Uint16 port,Uint32 clk ,Uint32 baudrate);
extern void SciSet(Sci_Obj_Int_p target);

inline Uint16 Sci_in_one_char(Sci_Obj_Int_p target)
{
    return Sci_Regs_Pt->SCIRXBUF.all;
}

inline void Sci_out_one_char(Sci_Obj_Int_p target,Uint16 ch)
{
    Sci_Regs_Pt->SCITXBUF.all = ch;
}

inline bool Sci_tx_is_busy(Sci_Obj_Int_p target)
{
    return (Sci_Regs_Pt->SCICTL2.bit.TXRDY == 0);
}

inline bool Sci_rx_is_ready(Sci_Obj_Int_p target)
{
    return (Sci_Regs_Pt->SCIFFRX.bit.RXFFST != 0);
}

inline bool Sci_err_occur(Sci_Obj_Int_p target)
{
    return (Sci_Regs_Pt->SCIRXST.bit.RXERROR == 1);
}

inline void Sci_Reset(Sci_Obj_Int_p target)
{
    Sci_Regs_Pt->SCICTL1.all     = 0;
    Sci_Regs_Pt->SCICTL1.all     = 0x23;
}
//extern inline Uint16 Sci_in_one_char(Sci_Obj_Int_p target);
//extern inline void Sci_out_one_char(Sci_Obj_Int_p target,Uint16 ch);
//extern inline bool Sci_tx_is_busy(Sci_Obj_Int_p target);
//extern inline bool Sci_rx_is_ready(Sci_Obj_Int_p target);
//extern inline bool Sci_err_occur(Sci_Obj_Int_p target);
//extern inline void Sci_Reset(Sci_Obj_Int_p target);

#endif /* NJC_SCI_DRV_H_ */
