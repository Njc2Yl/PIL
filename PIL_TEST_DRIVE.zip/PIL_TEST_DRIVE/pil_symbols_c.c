

#include "pil.h"
#include"main.h"

// this file can be linked such that no Flash memory is consumed

#if !defined(PIL_PREP_TOOL) && !defined(NO_PREP_TOOL)
#include "pil_symbols_c.inc" // will be automatically generated
#endif

#pragma RETAIN(PIL_D_Guid)
PIL_CONST_DEF(unsigned char, Guid[], CODE_GUID);

#pragma RETAIN(PIL_D_CompiledDate)
PIL_CONST_DEF(unsigned char, CompiledDate[], COMPILE_TIME_DATE_STR);

#pragma RETAIN(PIL_D_CompiledBy)
PIL_CONST_DEF(unsigned char, CompiledBy[], USER_NAME);

#pragma RETAIN(PIL_D_FrameworkVersion)
PIL_CONST_DEF(uint16_t, FrameworkVersion, PIL_FRAMEWORK_VERSION);

#ifdef SCI_BAUD_RATE
#pragma RETAIN(PIL_D_BaudRate)
PIL_CONST_DEF(uint32_t, BaudRate, SCI_BAUD_RATE);
#endif

#pragma RETAIN(PIL_D_StationAddress)
PIL_CONST_DEF(uint16_t, StationAddress, 0);

#pragma RETAIN(PIL_D_FirmwareDescription)
PIL_CONST_DEF(char, FirmwareDescription[], "Codegen 2837x");

#ifdef PARALLEL_COM_PROTOCOL
#pragma RETAIN(PIL_D_ParallelComProtocol)
PIL_CONST_DEF(uint16_t, ParallelComProtocol, PARALLEL_COM_PROTOCOL);

#pragma RETAIN(PIL_D_ParallelComBufferAddress)
PIL_CONST_DEF(uint32_t, ParallelComBufferAddress, PARALLEL_COM_BUF_ADDR);

#pragma RETAIN(PIL_D_ParallelComBufferAddress)
PIL_CONST_DEF(uint16_t, ParallelComBufferLength, PARALLEL_COM_BUF_LEN);

#pragma RETAIN(PIL_D_ParallelComTimeoutMs)
PIL_CONST_DEF(uint16_t, ParallelComTimeoutMs, 1000);

#pragma RETAIN(PIL_D_ExtendedComTimingMs)
PIL_CONST_DEF(uint16_t, ExtendedComTimingMs, 2000);
#endif // PARALLEL_COM_PROTOCOL
