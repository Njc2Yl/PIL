

#include "pil.h"


// this file can be linked such that no Flash memory is consumed
#if !defined(PIL_PREP_TOOL) && !defined(NO_PREP_TOOL)
#include "pil_symbols_p.inc" // will be automatically generated
#endif

PIL_CONFIG_DEF(uint16_t, ProcessorPartNumber, 28377);
