/*
 * var_def.h
 *
 *  Created on: 2020��7��6��
 *      Author: ning_
 */
#include"F28x_Project.h"

#ifndef VAR_DEF_H_
#define VAR_DEF_H_

//struct var_in
//{
//    PIL_OVERRIDE_PROBE(Uint16, outputdata, 10, 1.0, "V");
//};


#endif /* VAR_DEF_H_ */
