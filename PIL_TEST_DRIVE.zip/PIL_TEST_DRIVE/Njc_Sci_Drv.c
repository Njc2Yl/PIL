/*
 * Njc_Sci_Drv.c
 *
 *  Created on: 2020��7��6��
 *      Author: ning_
 */
#include"Njc_Sci_Drv.h"

Sci_Obj_Int_p InitSciCfg(void *MemAdd,const Uint16 MemSize)
{
    if(MemSize < sizeof(Sci_Obj_Int))
    {
        return ((Sci_Obj_Int_p)NULL);
    }
    Sci_Obj_Int_p handle = (Sci_Obj_Int_p)MemAdd;
    return handle;
}

void SciCfg(Sci_Obj_Int_p target,Uint16 port,Uint32 clk ,Uint32 baudrate)
{
    target->port      = port;
    target->Lsp_Clk   = clk;
    target->Baud_rate = baudrate;
}

void SciSet(Sci_Obj_Int_p target)
{
    EALLOW;
        ClkCfgRegs.LOSPCP.bit.LSPCLKDIV = 2;
        switch(target->port)
        {
            case 0:
                GpioCtrlRegs.GPAPUD.bit.GPIO28 = 0;
                GpioCtrlRegs.GPAPUD.bit.GPIO29 = 0;

                GpioCtrlRegs.GPAQSEL2.bit.GPIO28 = 3;

                GpioCtrlRegs.GPAGMUX2.bit.GPIO28 = 0;
                GpioCtrlRegs.GPAMUX2.bit.GPIO28 = 1;
                GpioCtrlRegs.GPAGMUX2.bit.GPIO29 = 0;
                GpioCtrlRegs.GPAMUX2.bit.GPIO29 = 1;
                break;
            case 1:
                GpioCtrlRegs.GPCPUD.bit.GPIO85 = 0;
                GpioCtrlRegs.GPCPUD.bit.GPIO84 = 0;

                GpioCtrlRegs.GPCQSEL2.bit.GPIO85 = 3;

                GpioCtrlRegs.GPCGMUX2.bit.GPIO85 = 1;
                GpioCtrlRegs.GPCMUX2.bit.GPIO85 = 1;
                GpioCtrlRegs.GPCGMUX2.bit.GPIO84 = 1;
                GpioCtrlRegs.GPCMUX2.bit.GPIO84 = 1;
                break;
            case 2:
                GpioCtrlRegs.GPBPUD.bit.GPIO43 = 0;
                GpioCtrlRegs.GPBPUD.bit.GPIO42 = 0;

                GpioCtrlRegs.GPBQSEL1.bit.GPIO43 = 3;

                GpioCtrlRegs.GPBGMUX1.bit.GPIO43 = 3;
                GpioCtrlRegs.GPBMUX1.bit.GPIO43 = 3;
                GpioCtrlRegs.GPBGMUX1.bit.GPIO42 = 3;
                GpioCtrlRegs.GPBMUX1.bit.GPIO42 = 3;
                break;
            default:break;
        }
        target->port_handle_address     = (Uint32)&SciaRegs;
        Sci_Regs_Pt->SCICTL1.all        = 0;//reset
        Sci_Regs_Pt->SCICCR.bit.SCICHAR = 0x7;//8bit
        Sci_Regs_Pt->SCICTL1.bit.RXENA  = 1;//enable RX
        Sci_Regs_Pt->SCICTL1.bit.TXENA  = 1;//enable TX
        Sci_Regs_Pt->SCIHBAUD.bit.BAUD  = 0xff & ( (target->Lsp_Clk/(target->Baud_rate * 8) - 1) >> 8 );
        Sci_Regs_Pt->SCILBAUD.bit.BAUD  = 0xff & (target->Lsp_Clk/(target->Baud_rate * 8) - 1);
        Sci_Regs_Pt->SCIFFTX.all        = 0xE020;
        Sci_Regs_Pt->SCIFFRX.all        = 0x2000;
        Sci_Regs_Pt->SCIFFCT.all        = 0;
        Sci_Regs_Pt->SCICTL1.all        = 0x23;
        Sci_Regs_Pt->SCIPRI.bit.FREESOFT= 3;
    EDIS;
}


