#include"F28x_Project.h"
#include"Njc_Sci_Drv.h"
#include"pil.h"
#include "pil_ctrl.h"
#include"var_def.h"
/**
 * main.c
 */
PIL_READ_PROBE(float, inputdata, 0, 1.0, "v");

Sci_Obj_Int   sciobj;
Sci_Obj_Int_p sciobjptr;

PIL_Obj_t PilObj;
PIL_Handle_t PilHandle;

Uint16 ReceivedChar[8],testcount;


static interrupt void Timer_test_pil();

extern void PIL_setAndConfigScopeBuffer(PIL_Handle_t aPilHandle, uint16_t* aBufPtr, uint16_t aBufSize, uint16_t aMaxTraceWidthInWords);
static void SciPoll(PIL_Handle_t aHandle)
{
    if(Sci_err_occur(sciobjptr))
    {
        Sci_Reset(sciobjptr);
    }

    while(Sci_rx_is_ready(sciobjptr))
    {
        PIL_SERIAL_IN(aHandle, (int16)Sci_in_one_char(sciobjptr));
    }

    int16_t ch;
    if(!Sci_tx_is_busy(sciobjptr))
    {
        if(PIL_SERIAL_OUT(aHandle, &ch))
        {
            Sci_out_one_char(sciobjptr,ch);
        }
    }
}

void main(void)
{
    InitSysCtrl();
    DINT;
    InitPieCtrl();
    IER = 0x0000;
    IFR = 0x0000;
    InitPieVectTable();

    sciobjptr = InitSciCfg(&sciobj,sizeof(sciobj));
    SciCfg(sciobjptr,LaunchPad,50000000,115200);
    SciSet(sciobjptr);

    PilHandle = PIL_init(&PilObj, sizeof(PilObj));
    PIL_setGuid(PilHandle, PIL_GUID_PTR);
    PIL_setCtrlCallback(PilHandle, (PIL_CtrlCallbackPtr_t)PilCallback);

    PIL_setSerialComCallback(PilHandle, (PIL_CommCallbackPtr_t)SciPoll);
    PIL_setAndConfigScopeBuffer(PilHandle, (uint16_t *)0, 0, 0);

    PilInitOverrideProbes();
    PilInitCalibrations();

    //dispatcher
    EALLOW;
    PieVectTable.TIMER0_INT = &Timer_test_pil;
    EDIS;
    InitCpuTimers();
    ConfigCpuTimer(&CpuTimer0, 200, 500000);
    CpuTimer0Regs.TCR.all = 0x4001;
    IER |= M_INT1;
    PieCtrlRegs.PIEIER1.bit.INTx7 = 1;

    PIL_requestReadyMode(PilHandle);

    EINT;
    ERTM;
    for(;;)
    {
        PIL_backgroundCall(PilHandle);
    }
}


static interrupt void Timer_test_pil()
{
    CpuTimer0Regs.TCR.bit.TSS = 1;
    PieCtrlRegs.PIEACK.all = PIEACK_GROUP1;
    CpuTimer0Regs.TCR.bit.TIF = 1;
    //testcount++;
    //SET_OPROBE(var_in_int.outputdata,testcount);
    PIL_BEGIN_INT_CALL(PilHandle);
    CpuTimer0Regs.TCR.bit.TSS = 0;
//    PIL_SCOPE_sample(PilHandle);

}
